
export default function Footer () {
    return (
        <footer className="footer bg-black text-white text-center h-36 pt-16">
            Copyright &copy; 2021, www.test.sapiangroup.com
        </footer>
    )
}